//  one line comment 
/*
    여러 줄 주석 
    여러 줄 주석 
 */

//실행 단축키 (Code Runner)
// CTRl+ Alt +N

console.log('Hello Jooha learning Javascript;');